LABEL STUDIO - PDF to ZPL for Zebra printers

Put every file in this folder on any static web host, all side by side
(no subfolders). Open index.html's address in Safari, then
Share -> Add to Home Screen to install it like an app.

Easiest hosts (free):
- Netlify Drop: app.netlify.com/drop - drag this whole folder onto the page (from a computer).
- GitHub Pages: new public repo -> Add file -> Upload files -> select all files -> Commit,
  then Settings -> Pages -> Source: Deploy from a branch -> main -> / (root) -> Save.
